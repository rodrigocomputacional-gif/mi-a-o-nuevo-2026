
import React, { useState, useEffect } from 'react';
import { TimeLeft } from '../types';

export const Countdown: React.FC = () => {
  const calculateTimeLeft = (): TimeLeft => {
    const difference = +new Date('2026-01-01T00:00:00') - +new Date();
    let timeLeft: TimeLeft = { days: 0, hours: 0, minutes: 0, seconds: 0 };

    if (difference > 0) {
      timeLeft = {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }
    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState<TimeLeft>(calculateTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const TimeUnit = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center px-2 md:px-4">
      <span className="text-3xl md:text-5xl font-black text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.6)]">
        {value.toString().padStart(2, '0')}
      </span>
      <span className="text-[10px] md:text-xs uppercase tracking-widest text-white/60 font-medium">
        {label}
      </span>
    </div>
  );

  return (
    <div className="flex items-center space-x-1 glass p-4 rounded-3xl animate-pulse-slow">
      <TimeUnit value={timeLeft.days} label="Días" />
      <div className="text-2xl text-white/20 self-start mt-1">:</div>
      <TimeUnit value={timeLeft.hours} label="Horas" />
      <div className="text-2xl text-white/20 self-start mt-1">:</div>
      <TimeUnit value={timeLeft.minutes} label="Minutos" />
      <div className="text-2xl text-white/20 self-start mt-1">:</div>
      <TimeUnit value={timeLeft.seconds} label="Segs" />
    </div>
  );
};
