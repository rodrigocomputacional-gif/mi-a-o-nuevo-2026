
import React, { useEffect, useRef, useCallback } from 'react';
import { Particle, Firework } from '../types';

const COLORS = [
  '#ff0040', '#ff00ff', '#00ffff', '#00ff00', '#ffff00', '#ff8000', '#ffffff', '#ffd700'
];

export const FireworkCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fireworks = useRef<Firework[]>([]);

  const createParticles = (x: number, y: number, color: string): Particle[] => {
    const count = 50 + Math.random() * 50;
    const particles: Particle[] = [];
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 6 + 2;
      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        alpha: 1,
        color,
        size: Math.random() * 2 + 1
      });
    }
    return particles;
  };

  const addFirework = useCallback((x?: number, y?: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const startX = x ?? Math.random() * canvas.width;
    const startY = canvas.height;
    const targetY = y ?? Math.random() * (canvas.height * 0.5);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    fireworks.current.push({
      x: startX,
      y: startY,
      targetY,
      vx: (Math.random() - 0.5) * 2,
      vy: -Math.random() * 10 - 5,
      color,
      exploded: false,
      particles: []
    });
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', resize);
    resize();

    let animationFrameId: number;

    const update = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      fireworks.current.forEach((fw, index) => {
        if (!fw.exploded) {
          fw.x += fw.vx;
          fw.y += fw.vy;
          fw.vy += 0.15; // Gravity

          ctx.beginPath();
          ctx.arc(fw.x, fw.y, 2, 0, Math.PI * 2);
          ctx.fillStyle = fw.color;
          ctx.fill();

          if (fw.vy >= 0 || fw.y <= fw.targetY) {
            fw.exploded = true;
            fw.particles = createParticles(fw.x, fw.y, fw.color);
          }
        } else {
          fw.particles.forEach((p, pIndex) => {
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.05; // Particle gravity
            p.vx *= 0.98; // Friction
            p.vy *= 0.98;
            p.alpha -= 0.015;

            if (p.alpha <= 0) {
              fw.particles.splice(pIndex, 1);
            } else {
              ctx.globalAlpha = p.alpha;
              ctx.beginPath();
              ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
              ctx.fillStyle = p.color;
              ctx.fill();
            }
          });

          if (fw.particles.length === 0) {
            fireworks.current.splice(index, 1);
          }
        }
      });

      ctx.globalAlpha = 1;
      animationFrameId = requestAnimationFrame(update);
    };

    update();

    // Auto fireworks
    const interval = setInterval(() => {
      if (Math.random() < 0.3) addFirework();
    }, 800);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
      clearInterval(interval);
    };
  }, [addFirework]);

  const handleCanvasClick = (e: React.MouseEvent) => {
    addFirework(e.clientX, e.clientY);
  };

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 z-0 cursor-crosshair" 
      onClick={handleCanvasClick}
    />
  );
};
