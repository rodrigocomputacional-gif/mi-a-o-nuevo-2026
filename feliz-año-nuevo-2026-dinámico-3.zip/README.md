
# 🎆 Feliz Año Nuevo 2026 - Experiencia Dinámica

¡Bienvenido al proyecto de celebración del 2026! Esta es una aplicación web interactiva diseñada para recibir el nuevo año con estilo.

## ✨ Características principales
- **Fuegos Artificiales**: Sistema de partículas interactivo (haz clic para lanzar cohetes).
- **Cuenta Regresiva**: Reloj en tiempo real hasta el 1 de enero de 2026.
- **Deseos con IA**: Generador de mensajes inspiradores usando la tecnología de Google Gemini.
- **Diseño Adaptable**: Se ve perfecto en celulares, tablets y computadoras.

## 🛠️ Tecnologías utilizadas
- **React 19** para la interfaz.
- **Tailwind CSS** para los estilos elegantes.
- **Canvas API** para la animación fluida de los fuegos artificiales.
- **Google Gemini API** para la creación de mensajes dinámicos.

---
*Instrucciones: Para ver la aplicación funcionando, se recomienda subir este repositorio a una plataforma de despliegue como Vercel o Netlify.*
