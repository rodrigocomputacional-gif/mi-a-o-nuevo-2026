
import { GoogleGenAI } from "@google/genai";

export const generateNewYearWish = async (): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Genera un mensaje corto, inspirador y creativo de 'Feliz Año Nuevo 2026' en español. Que sea emocionante y mire hacia el futuro. Máximo 100 caracteres.",
      config: {
        temperature: 0.9,
      },
    });

    return response.text?.trim() || "¡Que el 2026 sea tu mejor año lleno de luz y éxitos!";
  } catch (error) {
    console.error("Error generating wish:", error);
    return "¡Brindemos por un 2026 espectacular lleno de alegría!";
  }
};
