
import React, { useEffect, useRef, useCallback } from 'react';
import { Particle, Firework } from '../types';

const COLORS = [
  '#ff0040', '#ff00ff', '#00ffff', '#00ff00', '#ffff00', '#ff8000', 
  '#ffffff', '#ffd700', '#00aaff', '#ff5500'
];

export const FireworkCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fireworks = useRef<Firework[]>([]);

  const createParticles = (x: number, y: number, color: string): Particle[] => {
    const count = 80 + Math.random() * 40;
    const particles: Particle[] = [];
    const type = Math.random();

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      let speed;
      
      // Diferentes tipos de explosión
      if (type > 0.7) { // Explosión circular perfecta
        speed = 4 + Math.random() * 2;
      } else { // Explosión orgánica
        speed = Math.random() * 8 + 2;
      }

      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        alpha: 1,
        color,
        size: Math.random() * 2.5 + 0.5
      });
    }
    return particles;
  };

  const addFirework = useCallback((x?: number, y?: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const startX = x ?? Math.random() * canvas.width;
    const startY = canvas.height;
    const targetY = y ?? Math.random() * (canvas.height * 0.4) + 100;
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    fireworks.current.push({
      x: startX,
      y: startY,
      targetY,
      vx: (Math.random() - 0.5) * 3,
      vy: -Math.random() * 8 - 8,
      color,
      exploded: false,
      particles: []
    });
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', resize);
    resize();

    let animationFrameId: number;

    const render = () => {
      // Fondo con rastro (trail effect)
      ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      fireworks.current.forEach((fw, index) => {
        if (!fw.exploded) {
          // Fase de ascenso
          fw.x += fw.vx;
          fw.y += fw.vy;
          fw.vy += 0.12; // Gravedad suave

          // Dibujar estela del cohete
          ctx.beginPath();
          ctx.arc(fw.x, fw.y, 1.5, 0, Math.PI * 2);
          ctx.fillStyle = fw.color;
          ctx.fill();

          // Partículas de rastro del cohete
          if (Math.random() > 0.5) {
            ctx.fillStyle = 'rgba(255,255,255,0.3)';
            ctx.fillRect(fw.x, fw.y + 5, 1, 1);
          }

          if (fw.vy >= 0 || fw.y <= fw.targetY) {
            fw.exploded = true;
            fw.particles = createParticles(fw.x, fw.y, fw.color);
          }
        } else {
          // Fase de explosión
          fw.particles.forEach((p, pIndex) => {
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.07; // Gravedad de partículas
            p.vx *= 0.96; // Fricción aire
            p.vy *= 0.96;
            p.alpha -= 0.012;

            if (p.alpha <= 0) {
              fw.particles.splice(pIndex, 1);
            } else {
              ctx.save();
              ctx.globalAlpha = p.alpha;
              ctx.beginPath();
              ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
              ctx.fillStyle = p.color;
              // Añadir brillo a las partículas
              ctx.shadowBlur = 5;
              ctx.shadowColor = p.color;
              ctx.fill();
              ctx.restore();
            }
          });

          if (fw.particles.length === 0) {
            fireworks.current.splice(index, 1);
          }
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    // Lanzamiento automático
    const interval = setInterval(() => {
      if (fireworks.current.length < 10) addFirework();
    }, 1200);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
      clearInterval(interval);
    };
  }, [addFirework]);

  const handlePointerDown = (e: React.PointerEvent) => {
    addFirework(e.clientX, e.clientY);
  };

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 z-0 cursor-crosshair touch-none" 
      onPointerDown={handlePointerDown}
    />
  );
};
