
import React, { useState, useEffect } from 'react';
import { TimeLeft } from '../types';

export const Countdown: React.FC = () => {
  const calculateTimeLeft = (): TimeLeft => {
    const difference = +new Date('2026-01-01T00:00:00') - +new Date();
    let timeLeft: TimeLeft = { days: 0, hours: 0, minutes: 0, seconds: 0 };

    if (difference > 0) {
      timeLeft = {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }
    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState<TimeLeft>(calculateTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const Digit = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="text-4xl md:text-6xl font-black text-white tracking-tighter tabular-nums">
        {value.toString().padStart(2, '0')}
      </div>
      <div className="text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-yellow-500 font-bold mt-1">
        {label}
      </div>
    </div>
  );

  return (
    <div className="flex items-center space-x-6 md:space-x-10 px-8 py-4 bg-white/5 rounded-full border border-white/10 backdrop-blur-md">
      <Digit value={timeLeft.days} label="Días" />
      <div className="h-8 w-[1px] bg-white/10 hidden md:block"></div>
      <Digit value={timeLeft.hours} label="Hrs" />
      <div className="h-8 w-[1px] bg-white/10 hidden md:block"></div>
      <Digit value={timeLeft.minutes} label="Min" />
      <div className="h-8 w-[1px] bg-white/10 hidden md:block"></div>
      <Digit value={timeLeft.seconds} label="Seg" />
    </div>
  );
};
