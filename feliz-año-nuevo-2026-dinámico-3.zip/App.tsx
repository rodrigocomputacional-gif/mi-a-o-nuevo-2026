
import React, { useState, useEffect, useCallback } from 'react';
import { FireworkCanvas } from './components/FireworkCanvas';
import { Countdown } from './components/Countdown';
import { generateNewYearWish } from './services/geminiService';

const App: React.FC = () => {
  const [wish, setWish] = useState<string>("Toca para iluminar el 2026...");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [showContent, setShowContent] = useState<boolean>(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowContent(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const handleNewWish = useCallback(async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setIsGenerating(true);
    const newWish = await generateNewYearWish();
    setWish(newWish);
    setIsGenerating(false);
  }, []);

  return (
    <div className="relative w-full h-[100dvh] flex flex-col items-center justify-between text-white py-12 px-6">
      {/* El Canvas está al fondo */}
      <FireworkCanvas />

      {/* Header: Título y Año */}
      <div className={`z-10 text-center transition-all duration-1000 ${showContent ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-10'}`}>
        <h2 className="text-xl md:text-2xl font-dancing text-yellow-400 mb-1 tracking-widest text-glow">
          ¡Brindemos por el futuro!
        </h2>
        <h1 className="text-8xl md:text-[12rem] font-black tracking-tighter leading-none select-none italic text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-500 drop-shadow-2xl">
          2026
        </h1>
      </div>

      {/* Middle: Countdown */}
      <div className={`z-10 transition-all duration-1000 delay-300 ${showContent ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}>
        <Countdown />
      </div>

      {/* Bottom: Card de Deseos */}
      <div className={`z-10 w-full max-w-lg transition-all duration-1000 delay-500 ${showContent ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <div className="glass rounded-[2.5rem] p-8 text-center relative overflow-hidden group border border-white/10">
          <i className="fa-solid fa-sparkles text-yellow-400/50 text-2xl mb-4 block animate-bounce"></i>
          
          <p className={`text-lg md:text-2xl font-dancing leading-relaxed mb-8 transition-all duration-500 min-h-[4rem] flex items-center justify-center ${isGenerating ? 'opacity-30 blur-sm' : 'opacity-100'}`}>
            {wish}
          </p>
          
          <div className="flex flex-col gap-4">
            <button 
              onClick={handleNewWish}
              disabled={isGenerating}
              className="relative py-4 px-8 bg-white text-black font-bold rounded-2xl hover:scale-105 active:scale-95 transition-all duration-300 shadow-xl flex items-center justify-center space-x-3 overflow-hidden"
            >
              {isGenerating ? (
                <i className="fa-solid fa-spinner animate-spin"></i>
              ) : (
                <>
                  <i className="fa-solid fa-wand-magic-sparkles text-yellow-600"></i>
                  <span>DESCUBRIR DESEO 2026</span>
                </>
              )}
            </button>
            
            <p className="text-[10px] uppercase tracking-[0.3em] text-white/30 font-bold">
              Toca el cielo para más fuegos artificiales
            </p>
          </div>
        </div>
      </div>

      {/* Decoración de esquinas */}
      <div className="fixed top-0 left-0 w-32 h-32 bg-blue-500/10 blur-[100px] pointer-events-none"></div>
      <div className="fixed bottom-0 right-0 w-32 h-32 bg-purple-500/10 blur-[100px] pointer-events-none"></div>
    </div>
  );
};

export default App;
