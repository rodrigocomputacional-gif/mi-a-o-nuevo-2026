
import React, { useState, useEffect, useCallback } from 'react';
import { FireworkCanvas } from './components/FireworkCanvas';
import { Countdown } from './components/Countdown';
import { generateNewYearWish } from './services/geminiService';

const App: React.FC = () => {
  const [wish, setWish] = useState<string>("¡Toca la pantalla para iluminar tu futuro!");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
  }, []);

  const handleGetWish = async (e: React.MouseEvent) => {
    e.stopPropagation(); // Evitar que el clic en el botón lance un fuego artificial accidental
    setIsGenerating(true);
    const newWish = await generateNewYearWish();
    setWish(newWish);
    setIsGenerating(false);
  };

  return (
    <div className={`relative min-h-[100dvh] flex flex-col items-center justify-between p-6 transition-opacity duration-1000 ${visible ? 'opacity-100' : 'opacity-0'}`}>
      <FireworkCanvas />

      {/* Título Principal */}
      <div className="z-10 text-center mt-10">
        <p className="text-yellow-400 font-dancing text-2xl md:text-3xl mb-2 tracking-widest">
          Brindemos por un nuevo comienzo
        </p>
        <h1 className="text-8xl md:text-[12rem] font-black tracking-tighter leading-none glow-text select-none">
          2026
        </h1>
      </div>

      {/* Contador Central */}
      <div className="z-10 my-8">
        <Countdown />
      </div>

      {/* Tarjeta de Mensaje IA */}
      <div className="z-10 w-full max-w-lg mb-10">
        <div className="glass rounded-[3rem] p-8 md:p-10 text-center relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-yellow-400 to-transparent opacity-50"></div>
          
          <i className="fa-solid fa-wand-magic-sparkles text-yellow-400 text-3xl mb-6 block animate-pulse"></i>
          
          <p className={`text-xl md:text-2xl font-dancing leading-relaxed min-h-[5rem] flex items-center justify-center transition-all duration-500 ${isGenerating ? 'opacity-20 blur-sm' : 'opacity-100'}`}>
            "{wish}"
          </p>

          <button 
            onClick={handleGetWish}
            disabled={isGenerating}
            className="mt-8 w-full py-4 bg-gradient-to-r from-yellow-500 to-yellow-300 text-black font-bold rounded-2xl hover:scale-105 active:scale-95 transition-all shadow-[0_0_20px_rgba(255,215,0,0.3)] disabled:opacity-50 flex items-center justify-center gap-3"
          >
            {isGenerating ? (
              <i className="fa-solid fa-spinner animate-spin"></i>
            ) : (
              <>
                <i className="fa-solid fa-bolt"></i>
                <span>GENERAR DESEO MÁGICO</span>
              </>
            )}
          </button>
          
          <p className="mt-4 text-[10px] uppercase tracking-[0.4em] text-white/30 font-bold">
            Interactúa con el cielo para celebrar
          </p>
        </div>
      </div>

      {/* Luces decorativas de fondo */}
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none"></div>
    </div>
  );
};

export default App;
