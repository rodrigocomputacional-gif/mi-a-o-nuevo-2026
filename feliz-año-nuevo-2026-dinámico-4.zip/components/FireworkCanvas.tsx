
import React, { useEffect, useRef, useCallback } from 'react';
import { Particle, Firework } from '../types';

const COLORS = [
  '#ff0055', '#00fbff', '#ffeb3b', '#4caf50', '#9c27b0', '#ff9800', 
  '#ffffff', '#00ff9d', '#ff00ff', '#2196f3'
];

export const FireworkCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fireworks = useRef<Firework[]>([]);

  const createParticles = (x: number, y: number, color: string): Particle[] => {
    const particles: Particle[] = [];
    const count = 100; // Más partículas para efecto "dinamita"
    
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 8 + 2;
      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        alpha: 1,
        color,
        size: Math.random() * 3 + 1
      });
    }
    return particles;
  };

  const addFirework = useCallback((x?: number, y?: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const startX = x ?? Math.random() * canvas.width;
    const startY = canvas.height;
    const targetY = y ?? Math.random() * (canvas.height * 0.5);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    fireworks.current.push({
      x: startX,
      y: startY,
      targetY,
      vx: (Math.random() - 0.5) * 4,
      vy: -Math.random() * 10 - 10,
      color,
      exploded: false,
      particles: []
    });
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', resize);
    resize();

    let animationId: number;

    const animate = () => {
      // Trail effect: pintar un rectángulo negro semi-transparente
      ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      fireworks.current.forEach((fw, i) => {
        if (!fw.exploded) {
          // Fase de subida
          fw.x += fw.vx;
          fw.y += fw.vy;
          fw.vy += 0.15; // gravedad

          ctx.beginPath();
          ctx.arc(fw.x, fw.y, 2, 0, Math.PI * 2);
          ctx.fillStyle = fw.color;
          ctx.fill();

          if (fw.vy >= 0 || fw.y <= fw.targetY) {
            fw.exploded = true;
            fw.particles = createParticles(fw.x, fw.y, fw.color);
          }
        } else {
          // Fase de explosión
          fw.particles.forEach((p, j) => {
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.08; // gravedad de partículas
            p.vx *= 0.96; // fricción
            p.vy *= 0.96;
            p.alpha -= 0.015;

            if (p.alpha <= 0) {
              fw.particles.splice(j, 1);
            } else {
              ctx.globalAlpha = p.alpha;
              ctx.beginPath();
              ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
              ctx.fillStyle = p.color;
              ctx.shadowBlur = 10;
              ctx.shadowColor = p.color;
              ctx.fill();
            }
          });

          if (fw.particles.length === 0) {
            fireworks.current.splice(i, 1);
          }
        }
      });

      ctx.globalAlpha = 1;
      ctx.shadowBlur = 0;
      animationId = requestAnimationFrame(animate);
    };

    animate();

    // Lanzamiento automático ocasional
    const interval = setInterval(() => {
      if (fireworks.current.length < 5) addFirework();
    }, 1500);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
      clearInterval(interval);
    };
  }, [addFirework]);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 z-0 touch-none cursor-crosshair"
      onPointerDown={(e) => addFirework(e.clientX, e.clientY)}
    />
  );
};
